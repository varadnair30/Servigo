package com.Varad.Servigo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServigoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServigoApplication.class, args);
	}

}
