package com.Varad.Servigo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServigoApplicationTests {

	@Test
	void contextLoads() {
	}

}
